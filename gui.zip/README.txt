Developed by Moritz Sontheimer
This app is for segmentation of solder
It is based on the simpleGUI in python library and his based on https://realpython.com/pysimplegui-python/
